# xmind-maps
Repositório de mapas mentais compatíveis com XMind inicialmente criados por José Nogueira, membro do grupo de Telegram CCNA Brasil, e estão sob a licença GPLv3.

Todos os mapas são compatíveis com a versão 8 Update 8 do XMind, disponível gratuitamente para download em:

https://www.xmind.net/download/xmind8






